<?php
include 'functions.php';
if (stripos(file_get_contents("./other/switch.txt"), "on") !== false) {
if (!isset($_POST['UDID'])) {
echo <<< EOT
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>Raider Gamer</title>
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <link href="./js/bootstrap.min.js" rel="stylesheet">
      <link href="./css/style-cleaned.css" rel="stylesheet">
      <script language="javascript" type="text/javascript">
         function randomString() {
         	var chars = "0123456789abcdefghiklmnopqrstuvwxyz";
         	var randomstring = '';
         	for (var i=0; i<18; i++) {
         		var rnum = Math.floor(Math.random() * chars.length);
         		randomstring += chars.substring(rnum,rnum+1);
         	}
         	document.test.UDID.value = randomstring;
         }
           
      </script>
   </head>
   <body class="login">
      <div class="logo">
         <img src="./other/logo-big.png" alt=""> 
      </div>
      <div class="content">
         <!-- BEGIN LOGIN FORM -->
         <form action="" method="post" name="test">
            <span>UDID</span>
            <br>
            <input style="width:255px; height:30px;" size="40" name="UDID" align="middle" type="text">
            <a class="R" onclick="randomString();">R</a>
            <br><br>
            <center>
               <span>GAME:</span>
               <select name="GAME">
                  <option value="iMobsters">iMobsters</option>
                  <option value="WorldWar">WorldWar</option>
                  <option value="KingLive">KingLive</option>
                  <option value="NinjaLive">NinjaLive</option>
                  <option value="PetsLive">PetsLive</option>
                  <option value="RaceLive">RaceLive</option>
                  <option value="VampLive">VampLive</option>
                  <option value="ZombLive">ZombLive</option>
               </select>
               <br><br>
               <input class="Random" value="Login" type="Submit">
            </center>
         </form>
         <center>
            <span style="font-size: 20pt">Attention:</span>
            <br>
         </center>
         <left>
               <span>HOW TO USE
            <br>
                 1. Create a unique UDID using the R button or use your existing UDID if you already know it. 
            <br>
                 2. Select your Storm8 game from the drop-down menu and hit the Login button. Enjoy!
            <br><br>
                 HOW TO TRANSFER
            <br> Go to level 2 -> HOME -> SETTINGS (cog icon) -> STORM8 Tab -> Begin Resume/Transfer BUTTON -> New -> S8 ID and Password
</a>
            <br><br>
            <span><b>APPLE USERS:</b> Go in Safari browser Settings -> Cookies -> Clear your Cookies/Data and always ALLOW COOKIES</span>
            <br><br>
            <span><b>ANDROID APP</b></span><a href="./other/RaiderGamer.apk"> Carnage Gamer</a>
            <br><br>
            <span>If you need help, contact Raiderwolf in Palringo </span> <a href="http://palringo.com/i/ATz2rg/L8hp">[s8 games]</a> chat room.
            <br><br>
         </left>
      </div>
   </body>
</html>
EOT;
}
else {
$udid = $_POST['UDID'];
$game = $_POST['GAME'];
$shortc = GetGameShortC($game);
echo <<< EOT
<html>
    <head>
		<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
		<meta name="apple-mobile-web-app-capable" content="yes" />
		<style type="text/css">
            iframe#test {
            background-color: black;
            border: none;
            }
            .menuStrip {
            height:37px;
            background-image:url(http://im.storm8.com/images/tabGradient.png?v=30);
            background-repeat:repeat-x;
            font-size:16px;
            color:white;
		</style>
   </head>
   <body marginwidth="0" marginheight="0" bgcolor="#000">
        <center>
			<div class="menuStrip">
				<div id="menu" class="menuBar">
					<img src="https://im.storm8.com/images/tab/tab_home.png" onmouseover="this.src='https://im.storm8.com/images/tab/tab_home_selected.png'" onmouseout="this.src='https://im.storm8.com/images/tab/tab_home.png'" onclick="document.getElementById('test').src='http://$shortc.storm8.com/home.php'"><img src="https://im.storm8.com/images/tab/tab_mission.png" onmouseover="this.src='https://im.storm8.com/images/tab/tab_mission_selected.png'" onmouseout="this.src='https://im.storm8.com/images/tab/tab_mission.png'" onclick="document.getElementById('test').src='http://$shortc.storm8.com/missions.php'"><img src="https://im.storm8.com/images/tab/tab_fight.png" onmouseover="this.src='https://im.storm8.com/images/tab/tab_fight_selected.png'" onmouseout="this.src='https://im.storm8.com/images/tab/tab_fight.png'" onclick="document.getElementById('test').src='http://$shortc.storm8.com/fight.php'"><img src="https://im.storm8.com/images/tab/tab_item.png" onmouseover="this.src='https://im.storm8.com/images/tab/tab_item_selected.png'" onmouseout="this.src='https://im.storm8.com/images/tab/tab_item.png'" onclick="document.getElementById('test').src='http://$shortc.storm8.com/equipment.php'"><img src="https://im.storm8.com/images/tab/tab_group.png" onmouseover="this.src='https://im.storm8.com/images/tab/tab_group_selected.png'" onmouseout="this.src='https://im.storm8.com/images/tab/tab_group.png'" onclick="document.getElementById('test').src='http://$shortc.storm8.com/group.php'">
				</div>
			</div>
			<br>
EOT;
    echo '<iframe id="test" src="' . htmlspecialchars(GetGameLink($game, $udid)) . '" width="100%" height="95%" scrolling="yes"></iframe>';
echo <<< EOT
	    </center>
    </body>
</html>
EOT;
}
} else{
  echo '<body bgcolor="#000000"><p><font color="red">Trial Not Available! Private message Carnage to reopen it. The source code of this login script is available via PayPal for $30.00 USD.</font></p></body>';
  }  
?>
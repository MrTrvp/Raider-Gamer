<?php

function GetGameLink($game = "iMobsters", $udid = 1){
	if ($game == "iMobsters"){
	$Link = 'http://im.storm8.com/apoints.php?fpts=12&version=a1.54&udid=' . $udid . '&pf=' . md5($udid . ":kIndl3F1rE158i:12") . '&model=Droid&sv=2.2';
	} elseif ($game == "WorldWar"){
	$Link = 'http://wwar.storm8.com/apoints.php?version=a1.56&udid=' . $udid . '&pf=' . md5($udid . ":meRRyChr1stM4s157w") . '&model=Droid&sv=9A405';
	} elseif ($game == "KingLive"){
	$Link = 'http://kl.storm8.com/apoints.php?version=a1.56&udid=' . $udid . '&pf=' . md5($udid . ":midDen9eard156k") . '&model=Droid&sv=9A405';
	} elseif ($game == "NinjaLive"){
	$Link = 'http://nl.storm8.com/apoints.php?version=a1.56&udid=' . $udid . '&pf=' . md5($udid . ":yAmat0t4keru156n") . '&model=Droid&sv=9A405';
	} elseif ($game == "PetsLive"){
	$Link = 'http://pl.storm8.com/apoints.php?version=a1.54&udid=' . $udid . '&pf=' . md5($udid . ":Chiw33nie156p") . '&model=Droid&sv=9A405';
	} elseif ($game == "RaceLive"){
	$Link = 'http://rl.storm8.com/apoints.php?version=a1.56&udid=' . $udid . '&pf=' . md5($udid . ":comput3rSk1ll") . '&model=Droid&sv=9A405';
	} elseif ($game == "VampLive"){
	$Link = 'http://vl.storm8.com/apoints.php?fpts=12&version=a1.54&udid=' . $udid . '&pf=' .  md5($udid . ":S3wuEWSzsy154v:12") . '&model=Droid&sv=9A405';
	} elseif($game == "ZombLive"){
	$Link = 'http://zl.storm8.com/apoints.php?version=a1.56&udid=' . $udid . '&pf=' .  md5($udid . ":RegisterToday143z") . '&model=Droid&sv=9A405';
	}
	return $Link;
} 

function GetGameShortC($game = "iMobsters"){
	if ($game == "iMobsters"):
	$shortc = "im";
	elseif ($game == "WorldWar"):
	$shortc = "wwar";
	elseif ($game == "KingLive"):
	$shortc = "kl";
	elseif ($game == "NinjaLive"):
	$shortc = "nl";
	elseif ($game == "PetsLive"):
	$shortc = "pl";
	elseif ($game == "RaceLive"):
	$shortc = "rl";
	elseif ($game == "VampLive"):
	$shortc = "vl";
	elseif($game == "ZombLive"):
	$shortc = "zl";
	endif;
	return $shortc;
} 
?>
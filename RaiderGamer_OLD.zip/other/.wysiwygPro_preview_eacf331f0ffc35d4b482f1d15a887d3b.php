<?php
if ($_GET['randomId'] != "VSCrBlVWmtpHfeFiZHgBLTAW25Tbu3sShxh5xggfvEtbMYTq42Zpes5SC8RvtvCX") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
